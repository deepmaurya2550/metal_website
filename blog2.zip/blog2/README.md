# personal-blog
 
 PHP PDO
 
 design framework: bootstrap v4
 
 Database: MySql
 
 (PDO style followed which is secured than mysqli commands)
  
 User Panel:
 1. Register
 2. Log in
 3. Post on blog with image
 4. Add comments on posts
 
 Admin Panel:
 1. admin log in
 2. approve or decline users
 3. approve or decline posts
 4. approve or decline comments
 5. passwords are md5 encrypted, so change at sql to login as admin

#### sql file is attached inside the sql directory.

n.b.: admin panel is at project-folder/admin
admin login
email: admin@gmail.com
password: 12345678

### Preview: Home Page

![Homepage preview](https://github.com/ashraf-Deepak/personal-blog/blob/master/personal-blog-home-preview.png)

### Raise a star to support me